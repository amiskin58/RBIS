# RBIS Score Information Architecture

## Product Structure

RBIS Score

│

├── Home

├── Game

│ ├── Game List

│ ├── Create Game

│ ├── Edit Game

│ ├── Lineup

│ └── Start Game

│

├── Live Score

│ ├── Pitch

│ ├── Play

│ ├── Runner

│ ├── Substitution

│ ├── Replay

│ └── Finish Game

│

├── Report

│ ├── Box Score

│ ├── Statistics

│ └── Export

│

└── Settings

----------------------------------------

## Home

功能：

- 最近比賽
- 建立比賽
- 繼續比賽

----------------------------------------

## Game

管理所有比賽。

----------------------------------------

## Live Score

即時紀錄所有 Event。

----------------------------------------

## Report

查看所有統計。

----------------------------------------

## Settings

系統設定。